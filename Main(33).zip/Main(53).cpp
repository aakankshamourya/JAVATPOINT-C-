// C++ Program to show the syntax/working of Objects as a
// part of Object Oriented PProgramming
#include <iostream>
using namespace std;
int main(){
  int a=4;
  int b=5;
  int x=3;
  int y=6;
  cout<<((a+b)>=(x+y));
  return 0;
  }
  

