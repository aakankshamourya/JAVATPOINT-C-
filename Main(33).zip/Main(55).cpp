// C++ Program to show the syntax/working of Objects as a
// part of Object Oriented PProgramming
#include <iostream>
using namespace std;
int main(){
  int x=5;
  std::cout<<(x>>1)<<std::endl;
  return 0;
  }
  

