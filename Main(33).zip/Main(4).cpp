#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
cout<<sqrt(64)<<"\n";
cout<<round(2.6)<<"\n";
cout<<log(2);
}