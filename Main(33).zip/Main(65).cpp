#include <iostream>  
using namespace std;  
   
int main () {  
        for (; ;)    
          {    
                  cout<<"Infinitive For Loop";    
          }    
    }   
