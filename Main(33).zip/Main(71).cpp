//C++ Infinitive do-while Loop in C++
    #include <iostream>  
    using namespace std;  
    int main() {  
          do{    
                  cout<<"Infinitive do-while Loop";    
              } while(true);     
    }  
