#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
int myAge = 25;
int votingAge = 89;
if(myAge>=votingAge){
  cout<<"old enough to vote";
}else{
  cout<<"Not old enough to vote";
}
}