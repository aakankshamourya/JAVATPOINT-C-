// C++ Program to show the syntax/working of Objects as a
// part of Object Oriented PProgramming
// embedded assignment expression
#include <iostream>
using namespace std;
int main(){
  int a;
  int b;
  a=10+(b=90);
  std::cout<<"Values of 'a' and 'b' are:"<<a<<","<<b<<std::endl;
  
  return 0;
  }
  

