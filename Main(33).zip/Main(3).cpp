#include <iostream>
#include<string>
using namespace std;

int main() 
{
cout<<min(10,20);
}