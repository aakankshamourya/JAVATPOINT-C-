#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
int num[5]={56,68,37,30,90};
cout<<sizeof(num);
}
