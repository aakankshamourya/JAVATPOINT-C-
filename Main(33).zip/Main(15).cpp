#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
int day=4;
switch(day){
  case 1:
  cout<<"Monday";
  break;
  case 2:
  cout<<"Tuesday";
  break;
  case3:
  cout<<"wednesday";
  break;
  case 4:
  cout<<"Thursday";
  break;
  case 5:
  cout<<"Friday";
  break;
  case 6:
  cout<<"saturday";
  break;
  case 7:
  cout<<"sunday";
  break;
}
}