#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
string h[5]={"hjdjh","hasj","jhewjhe","nbehe","bsbbe"};
for(int i=0;i<5;i++){
  cout<<i<<" =  "<<h[i]<<"\n";
}
}
