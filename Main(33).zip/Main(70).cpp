//nested do-while loop in C++
    #include <iostream>  
    using namespace std;  
    int main() {  
         int i = 1;    
             do{    
                  int j = 1;          
                  do{    
                    cout<<i<<"\n";        
                      j++;    
                  } while (j <= 3) ;    
                  i++;    
              } while (i <= 3) ;     
    }  
