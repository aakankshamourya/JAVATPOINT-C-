// C++ Program to Find Largest Among
// Three Numbers Using if-else
// Statement
#include <bits/stdc++.h>
using namespace std;

// Driver code
int main()
{
  int n,i;
  cin>>n;
  while(n>0){
    cout<<n<<endl;
    cin>>n;
  }
  
  return 0;
}
