// C++ Program to show the syntax/working of Objects as a
// part of Object Oriented PProgramming
#include <iostream>
using namespace std;
int main(){
  int x;
  int y;
  int z;
  cout<<"enter the values of x and y";
  cin>>x>>y;
  z=x+y;
  cout<<"\n"<<"Value of z is:"<<z;
  return 0;
  }
  

