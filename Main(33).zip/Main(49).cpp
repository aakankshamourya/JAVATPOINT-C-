// C++ Program to show the syntax/working of Objects as a
// part of Object Oriented PProgramming
#include <iostream>
using namespace std;
int main(){
  float x=8.9;
  float y=5.6;
  float z;
  z=x+y;
  std::cout<<"value of z is:"<<z<<std::endl;
  return 0;
  }
  

