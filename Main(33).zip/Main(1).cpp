#include <iostream>
#include<string>
using namespace std;

int main() 
{
std::string  greeting="Hi";
std::cout<<greeting;
return 0;
}