#include <iostream>  
using namespace std;  
   
int main () {  
        int i=1;
        while(true)
        {
          cout<<"infinitive while loop:";
        }

          
    }   
