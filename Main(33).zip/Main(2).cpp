#include <iostream>
#include<string>
using namespace std;

int main() 
{
cout<<max(10,20);
}