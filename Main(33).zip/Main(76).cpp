//C++ Goto Statement Example in C++
    #include <iostream>  
    using namespace std;  
    int main() {  
      ineligible:
      cout<<"You are not eligible to vote!\n";
      cout<<"enter your age:\n";
      int age;
      cin>>age;
      if(age<18){
        goto ineligible;
      }
      else{
        cout<<"you are eligible to vote!";
      }
      } 
          