// C++ Program to show the syntax/working of Objects as a
// part of Object Oriented PProgramming
// compound assignment
#include <iostream>
using namespace std;
int main(){
  int a;
  if(a%2==0)
  {
    cout<<"It is even number:";
  }
  else{
    cout<<"it is odd number:";
  }
  return 0;
  }
  

