// C++ Program to show the syntax/working of Objects as a
// part of Object Oriented PProgramming
#include <iostream>
using namespace std;
int main(){
  float scientificNotation=3.0e5;
  cout<<scientificNotation;
  int sizeOfInt=sizeof(int);
  cout<<sizeOfInt;
  }
  

