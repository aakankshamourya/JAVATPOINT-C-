// C++ Program to show the syntax/working of Objects as a
// part of Object Oriented PProgramming
#include <iostream>
using namespace std;
int main(){
  int a=2;
  int b=7;
  int c=4;
  cout<<((a>b)||(a>c));
  return 0;
  }
  

