// C++ Program to Find Largest Among
// Three Numbers Using if-else
// Statement
#include <bits/stdc++.h>
using namespace std;

// Driver code
int main()
{
  int pocketmoney=3000;
  for(int date=1;date<=30;date++){
    if(date%2==0){
      continue;
  }
  if(pocketmoney==0){
    break;
  }
  cout<<"Go out Today!"<<endl;
  pocketmoney=pocketmoney-300;
  }
  
  return 0;
}
