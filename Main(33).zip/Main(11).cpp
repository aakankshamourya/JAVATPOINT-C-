#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
int x=90;
int y=20;
if(x>y){
  cout<<"x is greater then y";
}
}