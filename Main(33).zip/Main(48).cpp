// C++ Program to show the syntax/working of Objects as a
// part of Object Oriented PProgramming
#include <iostream>
using namespace std;
int main(){
  int x;
  int y=9;
  x=y+int(10.0);
  cout<<"value of x"<<x<<endl;
  return 0;
  }
  

