// C++ Program to show the syntax/working of Objects as a
// part of Object Oriented PProgramming
#include <iostream>
using namespace std;
int main(){
  int a;
  int A;
  cout<<"Enter the values of 'a' and 'A'";
  cin>>a;
  cin>>A;
  cout<<"\n The Values that you have entered are:"<<a<<" , "<<A;
  return 0;
  }
  

