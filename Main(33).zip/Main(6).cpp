#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
cout<<(10>9);
}