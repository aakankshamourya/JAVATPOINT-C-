// C++ Program to Find Largest Among
// Three Numbers Using if-else
// Statement
#include <bits/stdc++.h>
using namespace std;

// Driver code
int main()
{
  int n,i;
  cin>>n;
  int sum=0;
  for(i=1;i<=n;i++){
    sum=sum+i;
  }
  cout<<sum<<endl;
  
  return 0;
}
