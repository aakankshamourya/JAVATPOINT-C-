#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
int time = 22;
if (time < 10) {
  cout << "Good morning.";
} else if (time < 20) {
  cout << "Good day.";
} else {
  cout << "Good evening.";
}
}